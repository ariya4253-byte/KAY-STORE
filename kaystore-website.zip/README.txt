===================================================
   KAY STORE - PETUNJUK DEPLOY & PUBLISH WEBSITE
===================================================

Selamat! Website KAY STORE milikmu siap untuk dipublish ke internet secara GRATIS.

---------------------------------------------------
1. CARA PUBLISH DALAM 1 MENIT (NETLIFY DROP)
---------------------------------------------------
1. Siapkan file gambar QRIS resmi KAY STORE milikmu.
2. Ubah nama file gambar tersebut menjadi: qris-kaystore.jpg
3. Letakkan file 'qris-kaystore.jpg' di folder yang sama persis dengan 'index.html'.
4. Buka browser dan kunjungi: https://app.netlify.com/drop
5. Masukkan seluruh folder ini (atau drag & drop folder ini) ke area yang disediakan Netlify.
6. Tunggu beberapa detik, Netlify akan langsung memberikan Link Website KAY STORE yang sudah ONLINE di seluruh dunia!

---------------------------------------------------
2. FITUR UTAMA WEBSITE KAY STORE
---------------------------------------------------
- Dark Mode Premium & Responsive UI (Android, iPhone, Desktop)
- Kategori Produk: UID Cantik, SC Generate UID, File Polosan UID, Produk Premium
- Real-time Search & Filter Harga
- Sistem Checkout Otomatis dengan Order ID (KAY-YYYYMMDD-XXXX)
- Metode Pembayaran: DANA, GoPay, dan QRIS
- Form Upload Bukti Pembayaran
- Konfirmasi Pesanan Otomatis ke WhatsApp Admin (083812735434)
- Floating WhatsApp Button
- Dashboard Admin (/admin) lengkap dengan CRUD produk, manajemen pesanan, dan pengaturan toko.

---------------------------------------------------
3. AKSES DASHBOARD ADMIN
---------------------------------------------------
- Klik tombol "Admin Login" di pojok kanan atas website.
- Password Default: admin123 (Dapat diubah dari tab Pengaturan di dalam Dashboard Admin).

---------------------------------------------------
4. INTEGRASI DATABASE SUPABASE (OPSIONAL)
---------------------------------------------------
Jika di kemudian hari kamu ingin menyambungkan database cloud Supabase:
1. Buat project gratis di https://supabase.com
2. Buka Dashboard Admin -> Tab 'Pengaturan Toko'
3. Masukkan Supabase URL dan Anon Key kamu.
Website akan otomatis terhubung ke cloud database secara otomatis!

===================================================
   KAY STORE - Sell UID Cantik • SC Generate UID • File UID
===================================================
